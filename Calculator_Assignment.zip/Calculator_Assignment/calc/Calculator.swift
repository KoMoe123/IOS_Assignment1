//
//  Calculator.swift
//  calc
//
//  Created by MyatAungMoe on 22/3/24.
//  Copyright © 2024 UTS. All rights reserved.
//
import Foundation

class Calculator {
    
    /// For multi-step calculation, it's helpful to persist the existing result
    var currentResult = 0
    
    // Public function to perform calculation based on input arguments
    func calculate(args: [String]) -> String {
        // First try to evaluate expression
        if let result = evaluateExpression(args.joined(separator: " ")) {
            return String(result)
        }
        
        // If evaluation fails, fall back to performing operation
        if let result = performOperation(args: args) {
            return String(result)
        } else {
            return "Error: Invalid input or operation"
        }
    }
    
    // Function to perform operation based on input arguments
    // Function to perform operation based on input arguments
    private func performOperation(args: [String]) -> Int? {
        var result: Int?
        var index = 0
        var operation: Character?
        
        // Function to validate if a string represents a valid integer
        func isValidInteger(_ str: String) -> Bool {
            return Int(str) != nil
        }
        
        // Validate input before performing calculations
        for arg in args {
            if !isValidInteger(arg) && !["+","-","x","/","%"].contains(arg) {
                return handleInvalidInputError()
            }
        }
        
        // Iterate through the arguments
        while index < args.count {
            let arg = args[index]
            
            if isValidInteger(arg) {
                guard let number = Int(arg) else {
                    return handleInvalidInputError()
                }
                
                if let op = operation {
                    // Perform operation based on the operator
                    switch op {
                    case "+":
                        result = add(lhs: result ?? 0, rhs: number)
                    case "-":
                        result = subtract(lhs: result ?? 0, rhs: number)
                    case "x":
                        result = multiply(lhs: result ?? 1, rhs: number)
                    case "/":
                        if number != 0 {
                            result = divide(lhs: result ?? 0, rhs: number)
                        } else {
                            return handleDivisionByZeroError()
                        }
                    case "%":
                        result = modulus(lhs: result ?? 0, rhs: number)
                    default:
                        return handleInvalidOperationError()
                    }
                    operation = nil
                } else {
                    result = number
                }
            } else if arg.count == 1 && "+-x/%".contains(arg) {
                // Ensure that the operator is not preceded by another operator
                if operation != nil {
                    return handleInvalidInputError()
                }
                // Store the operator for the next operation
                operation = Character(arg)
            } else {
                // If the argument is neither a valid number nor operator, it's invalid input
                return handleInvalidInputError()
            }
            index += 1
        }
        
        // Check if the last number has been processed
        if operation != nil {
            return handleInvalidInputError()
        }
        
        return result
    }

    
    // Function to evaluate infix expression with proper operator precedence
    private func evaluateExpression(_ expression: String) -> Int? {
        // Operator precedence dictionary
        let precedence: [Character: Int] = ["+": 1, "-": 1, "x": 2, "/": 2, "%": 2]
        
        // Shunting-yard algorithm
        var outputQueue = [String]()
        var operatorStack = [Character]()
        
        let tokens = expression.components(separatedBy: .whitespacesAndNewlines)
        
        for token in tokens {
            if let number = Int(token) {
                outputQueue.append(String(number))
            } else if let op = token.first {
                while let lastOp = operatorStack.last,
                      let lastOpPrecedence = precedence[lastOp],
                      let opPrecedence = precedence[op],
                      lastOpPrecedence >= opPrecedence {
                    outputQueue.append(String(operatorStack.removeLast()))
                }
                operatorStack.append(op)
            }
        }
        while let op = operatorStack.popLast() {
            outputQueue.append(String(op))
        }
        
        // Evaluate postfix expression
        var stack = [Int]()
        for token in outputQueue {
            if let number = Int(token) {
                stack.append(number)
            } else if let op = token.first {
                if stack.count < 2 {
                    return nil // Invalid expression
                }
                let b = stack.removeLast()
                let a = stack.removeLast()
                switch op {
                case "+": stack.append(a + b)
                case "-": stack.append(a - b)
                case "x": stack.append(a * b)
                case "/": stack.append(a / b)
                case "%": stack.append(a % b)
                default: return nil // Invalid operator
                }
            }
        }
        
        if stack.count == 1 {
            return stack.first
        } else {
            return nil // Invalid expression
        }
    }
    
    // Error handling functions
    private func handleDivisionByZeroError() -> Int? {
        print("Error: Division by zero")
        return nil
    }
    
    private func handleInvalidOperationError() -> Int? {
        print("Error: Invalid operation")
        return nil
    }
    
    private func handleInvalidInputError() -> Int? {
        print("Error: Invalid input")
        return nil
    }
    
    private func handleIntegerOverflowError() -> Int? {
        print("Error: Input value exceeds the range of Int64")
        return nil
    }
    
    // Operator functions
    private func add(lhs: Int, rhs: Int) -> Int {
        return lhs + rhs
    }
    
    private func subtract(lhs: Int, rhs: Int) -> Int {
        return lhs - rhs
    }
    
    private func multiply(lhs: Int, rhs: Int) -> Int {
        return lhs * rhs
    }
    
    private func divide(lhs: Int, rhs: Int) -> Int {
        return lhs / rhs
    }
    
    private func modulus(lhs: Int, rhs: Int) -> Int {
        return lhs % rhs
    }
}
